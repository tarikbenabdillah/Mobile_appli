package com.me.firstapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText editTextAmount = findViewById(R.id.editTextAmount);
        Button btnCompute = findViewById(R.id.btnCompute);
        TextView textViewResult = findViewById(R.id.textViewResult);
        ListView listViewResult = findViewById(R.id.listViewResults);
        List<String> data = new ArrayList<>();
        ArrayAdapter<String> stringArrayAdapter = new
                ArrayAdapter<>(this, android.R.layout.simple_list_item_1, data);
        listViewResult.setAdapter(stringArrayAdapter);
        btnCompute.setOnClickListener((view) -> {
            double amount = Double.parseDouble(editTextAmount.getText().toString());
            double result = amount + amount;
            textViewResult.setText(String.valueOf(result));
            data.add("Le double de :" + amount + " est " + result);
            stringArrayAdapter.notifyDataSetChanged();
            editTextAmount.setText("");
        });
    }
}