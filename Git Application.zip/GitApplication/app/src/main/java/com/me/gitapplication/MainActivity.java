package com.me.gitapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.me.gitapplication.service.GitRepoServiceAPI;

import java.util.ArrayList;
import java.util.List;

import model.GitUser;
import model.GitusersResponse;
import model.UsersListViewModel;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    List<GitUser> data=new ArrayList<>();
    public static final String USER_LOGIN_PARAM="user.login";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy=new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        final EditText editTextQuery=findViewById(R.id.editTextquery);
        Button buttonSearch=findViewById(R.id.buttonsearch);
        ListView listViewUsers=findViewById(R.id.listeviewusers);
        UsersListViewModel listViewModel=new UsersListViewModel(this,R.layout.users_list_view_layout,data);
        listViewUsers.setAdapter(listViewModel);
        final Retrofit retrofit=new Retrofit.Builder()
                .baseUrl("https://api.github.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        buttonSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                String query=editTextQuery.getText().toString();
                GitRepoServiceAPI gitRepoServiceAPI=retrofit.create(GitRepoServiceAPI.class);
                Call<GitusersResponse> callgitusers=gitRepoServiceAPI.searchUsers(query);
                callgitusers.enqueue(new Callback<GitusersResponse>() {
                    @Override
                    public void onResponse(Call<GitusersResponse> call, Response<GitusersResponse> response) {
                        if(!response.isSuccessful()){
                            Log.i("indo",String.valueOf(response.code()));
                            return;
                    }
                    GitusersResponse gitusersResponse= response.body();
                        data.clear();
                        for (GitUser user:gitusersResponse.users){
                            data.add(user);
                        }
                        listViewModel.notifyDataSetChanged();
                }
                    @Override
                    public void onFailure(Call<GitusersResponse> call, Throwable t) {
                        Log.e("error","Error");
                    }
                });
            }
                                        });
        listViewUsers.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
             String login=data.get(position).login;
                Intent intent=new Intent(getApplicationContext(),RepositoryActivity.class);
                intent.putExtra(USER_LOGIN_PARAM,login);
                startActivity(intent);
            }
        });
    }

}