package model;

public class GitRepo {
        public int id;
        public String name;
        public String descriptions;
        public String language;

}
